﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composition.Classes
{
    public class Pencere
    {
        public int Sayi { get; set; }

        public Pencere(int sayi)
        {
            Sayi = sayi;
        }
    }
}
