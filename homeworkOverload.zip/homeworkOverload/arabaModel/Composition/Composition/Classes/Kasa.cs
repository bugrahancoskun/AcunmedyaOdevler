﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composition.Classes
{
    public class Kasa
    {
        public string Tip { get; set; }

        public Kasa(string tip)
        {
            Tip = tip;
        }
    }
}
